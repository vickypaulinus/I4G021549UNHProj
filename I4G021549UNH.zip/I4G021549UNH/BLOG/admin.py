from django.contrib import admin
from .model import Post

# Register your models here.

admin.site.register(Post)
